Asume el rol de un DBA experto en MySQL y arquitectura basada en DDD.

A partir del análisis de dominio previamente generado:

1. Traduce los agregados en modelos relacionales
2. Define:
   - Tablas por entidad
   - Value Objects como columnas o tablas
   - Enums como tablas catálogo
3. Define claves primarias y foráneas
4. Define restricciones de integridad

IMPORTANTE:
- Mantén coherencia con los agregados (Aggregate Roots)
- Evita relaciones que rompan límites de contexto

Entrega en Markdown estructurado.

-> No simplifiques el modelo.
-> No omitas reglas de negocio.
-> No asumas lógica en la aplicación: todo debe vivir en la base de datos.
