Asume el rol de un experto en Domain-Driven Design (DDD).

Analiza el documento Banco.md y realiza lo siguiente:

1. Identifica el lenguaje ubicuo del dominio
2. Define todos los Bounded Contexts
3. Identifica:
   - Entidades
   - Value Objects
   - Agregados
   - Eventos de dominio
4. Define las relaciones entre contextos (Context Map)
5. Clasifica reglas de negocio:
   - Invariantes (fuertes)
   - Reglas de proceso

Entrega el resultado en formato Markdown estructurado.

-> No simplifiques el modelo.
-> No omitas reglas de negocio.
-> No asumas lógica en la aplicación: todo debe vivir en la base de datos.
