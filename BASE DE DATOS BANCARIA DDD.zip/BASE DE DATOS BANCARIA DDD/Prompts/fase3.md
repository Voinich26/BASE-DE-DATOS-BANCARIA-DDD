Tomando como base la carpeta SDD:

Genera una carpeta llamada Banco_Based con:

Banco_Based/
│── 01_schema.sql
│── 02_catalogs.sql
│── 03_tables.sql
│── 04_constraints.sql
│── 05_triggers.sql
│── 06_procedures.sql
│── 07_seed_data.sql

Requisitos:

1. MySQL puro
2. Tablas normalizadas (3FN mínimo)
3. Triggers para:
   - Validación de estados
   - Control de saldo
4. Stored Procedures como servicios de dominio:
   - Crear préstamo
   - Aprobar préstamo
   - Ejecutar transferencia
5. Manejo de transacciones (BEGIN, COMMIT, ROLLBACK)
6. Seguridad básica (roles)

Cada archivo debe estar listo para ejecutar.

-> No simplifiques el modelo.
-> No omitas reglas de negocio.
-> No asumas lógica en la aplicación: todo debe vivir en la base de datos.
