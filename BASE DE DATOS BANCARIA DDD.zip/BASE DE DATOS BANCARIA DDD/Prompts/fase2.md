Genera una carpeta llamada SDD con la siguiente estructura:

SDD/
│── README.md
│── 01_Domain/
│── 02_Architecture/
│── 03_Data_Model/
│── 04_Business_Rules/
│── 05_Procedures/
│── 06_Triggers/
│── 07_Security/

Incluye:

1. Modelo de dominio (desde DDD)
2. Modelo relacional completo
3. Definición de:
   - Entidades
   - Agregados
   - Relaciones
4. Reglas de negocio clasificadas:
   - Constraints
   - Triggers
   - Stored Procedures
5. Flujos:
   - Préstamos
   - Transferencias
6. Diseño de Bitácora (NoSQL conceptual)

Cada archivo debe estar en Markdown y ser detallado.

-> No simplifiques el modelo.
-> No omitas reglas de negocio.
-> No asumas lógica en la aplicación: todo debe vivir en la base de datos.
