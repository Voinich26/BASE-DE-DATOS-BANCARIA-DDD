# SDD  Software Design Document
## Sistema de Gestión Bancaria — Core Transaccional

**Metodología:** Domain-Driven Design (DDD)
**Motor relacional:** MySQL 8.x
**Motor NoSQL:** MongoDB (Bitácora)
**Fecha:** 2026-05-03

---

## Estructura del documento

| Carpeta | Contenido | Fase |
|---|---|---|
| 01_Domain/ | Análisis de dominio DDD: lenguaje ubicuo, bounded contexts, agregados, eventos | FASE 0 |
| 02_Architecture/ | Arquitectura del sistema: capas, contextos, flujos de datos | FASE 2 |
| 03_Data_Model/ | Modelo relacional completo: tablas, columnas, FK, índices | FASE 1 |
| 04_Business_Rules/ | Reglas de negocio: invariantes, constraints, flujos de aprobación | FASE 2 |
| 05_Procedures/ | Stored Procedures: definición, parámetros, lógica, manejo de errores | FASE 2 |
| 06_Triggers/ | Triggers: evento, tabla, propósito, pseudocódigo | FASE 2 |
| 07_Security/ | Seguridad: roles, vistas, permisos, restricciones de acceso | FASE 2 |

---

## Principios de diseño

1. **Todo el comportamiento vive en la BD.** Ninguna regla de negocio se delega a la capa de aplicación.
2. **Bounded Contexts aislados.** Las FK entre contextos usan solo identificadores naturales.
3. **Máquinas de estado en datos.** Las transiciones válidas se almacenan en tablas, no en código.
4. **Auditoría total.** Toda operación crítica genera un registro inmutable en bitácora NoSQL.
5. **Seguridad en BD.** La visibilidad por rol se implementa con vistas y permisos de MySQL.

---

## Bounded Contexts

| BC | Nombre | Tipo | Tablas principales |
|---|---|---|---|
| BC-01 | Identidad y Acceso | Generic Domain | usuario, cat_rol, cat_estado_usuario |
| BC-02 | Gestión de Clientes | Supporting Domain | cliente_persona_natural, cliente_empresa |
| BC-03 | Cuentas Bancarias | Supporting Domain | cuenta_bancaria, cat_tipo_cuenta, cat_moneda |
| BC-04 | Préstamos y Créditos | Core Domain | prestamo, cat_estado_prestamo, prestamo_transicion_estado |
| BC-05 | Transferencias | Core Domain | transferencia, cat_estado_transferencia, config_umbral |
| BC-06 | Auditoría y Bitácora | Supporting Domain | bitacora_operaciones (NoSQL) |
| BC-07 | Productos Bancarios | Generic Domain | producto_bancario, cat_categoria_producto |

---

## Orden de ejecución de scripts SQL

```
01_schema.sql       → Crea BD, usuarios MySQL, configura charset y Event Scheduler
02_catalogs.sql     → Tablas catálogo (Value Objects enumerados)
03_tables.sql       → Tablas principales (Aggregate Roots)
04_constraints.sql  → Vistas de seguridad por rol
05a_sp_bitacora.sql → sp_registrar_bitacora (debe existir ANTES que los triggers)
05_triggers.sql     → Triggers de validación y auditoría
06_procedures.sql   → Stored Procedures (servicios de dominio)
07_seed_data.sql    → Datos iniciales, catálogos, datos de prueba y permisos
```

> **IMPORTANTE:** `05a_sp_bitacora.sql` debe ejecutarse antes de `05_triggers.sql` porque los triggers TRG-05, TRG-08, TRG-10 y TRG-12 llaman a `sp_registrar_bitacora`. Si los triggers se crean antes que el SP, MySQL los acepta pero fallan en tiempo de ejecución.

---

## Resumen de artefactos

| Artefacto | Cantidad |
|---|---|
| Tablas relacionales | 19 |
| Colecciones NoSQL | 1 |
| Triggers | 15 (13 originales + TRG-01b + TRG-14) |
| Stored Procedures | 9 (8 originales + SP-01b interno) |
| Vistas de seguridad | 10 |
| Invariantes cubiertas | 29/29 |
| Reglas de proceso | 25/25 |
| Eventos de dominio | 18 |
| MySQL Events | 1 (evt_vencimiento_transferencias) |
