-- ============================================================
-- 04_constraints.sql
-- Vistas de seguridad por rol (Row-Level Security)
-- Ejecutar después de 03_tables.sql
-- ============================================================

USE banco_ddd;

-- ------------------------------------------------------------
-- VISTAS DE SEGURIDAD POR ROL (RP-15 al RP-21)
-- La variable @id_usuario_sesion se establece al conectar
-- ------------------------------------------------------------

-- RP-15: Cliente Persona Natural — solo sus cuentas
CREATE OR REPLACE VIEW v_cuentas_cliente_pn AS
    SELECT cb.numero_cuenta, cb.id_tipo_cuenta, cb.saldo_actual,
           cb.id_moneda, cb.id_estado_cuenta, cb.fecha_apertura
    FROM cuenta_bancaria cb
    JOIN cliente_persona_natural cpn
         ON cb.id_titular = cpn.id_identificacion
        AND cb.tipo_titular = 'PERSONA_NATURAL'
    WHERE cpn.id_usuario = @id_usuario_sesion;

-- RP-15: Cliente Persona Natural — solo sus préstamos
CREATE OR REPLACE VIEW v_prestamos_cliente_pn AS
    SELECT p.id_prestamo, p.id_tipo_prestamo, p.monto_solicitado,
           p.monto_aprobado, p.tasa_interes, p.plazo_meses,
           p.id_estado_prestamo, p.fecha_solicitud,
           p.fecha_aprobacion, p.fecha_desembolso
    FROM prestamo p
    JOIN cliente_persona_natural cpn
         ON p.id_cliente_solicitante = cpn.id_identificacion
        AND p.tipo_cliente = 'PERSONA_NATURAL'
    WHERE cpn.id_usuario = @id_usuario_sesion;

-- RP-15: Cliente Persona Natural — solo sus transferencias
CREATE OR REPLACE VIEW v_transferencias_cliente_pn AS
    SELECT t.id_transferencia, t.cuenta_origen, t.cuenta_destino,
           t.monto, t.id_estado_transferencia,
           t.fecha_creacion, t.fecha_aprobacion
    FROM transferencia t
    WHERE t.id_usuario_creador = @id_usuario_sesion;

-- RP-16: Cliente Empresa  cuentas de su empresa
CREATE OR REPLACE VIEW v_cuentas_empresa AS
    SELECT cb.numero_cuenta, cb.id_tipo_cuenta, cb.saldo_actual,
           cb.id_moneda, cb.id_estado_cuenta, cb.fecha_apertura
    FROM cuenta_bancaria cb
    JOIN cliente_empresa ce
         ON cb.id_titular = ce.nit
        AND cb.tipo_titular = 'EMPRESA'
    WHERE ce.id_usuario = @id_usuario_sesion;

-- RP-16: Cliente Empresa  préstamos de su empresa
CREATE OR REPLACE VIEW v_prestamos_empresa AS
    SELECT p.id_prestamo, p.id_tipo_prestamo, p.monto_solicitado,
           p.monto_aprobado, p.tasa_interes, p.plazo_meses,
           p.id_estado_prestamo, p.fecha_solicitud,
           p.fecha_aprobacion, p.fecha_desembolso
    FROM prestamo p
    JOIN cliente_empresa ce
         ON p.id_cliente_solicitante = ce.nit
        AND p.tipo_cliente = 'EMPRESA'
    WHERE ce.id_usuario = @id_usuario_sesion;

-- RP-17: Empleado Ventanilla  todas las cuentas, sin datos de riesgo
CREATE OR REPLACE VIEW v_cuentas_ventanilla AS
    SELECT numero_cuenta, id_tipo_cuenta, id_titular, tipo_titular,
           saldo_actual, id_moneda, id_estado_cuenta, fecha_apertura
    FROM cuenta_bancaria;

-- RP-19: Empleado Empresa  transferencias de su empresa
CREATE OR REPLACE VIEW v_transferencias_empresa_op AS
    SELECT t.id_transferencia, t.cuenta_origen, t.cuenta_destino,
           t.monto, t.id_estado_transferencia,
           t.fecha_creacion, t.fecha_vencimiento, t.requiere_aprobacion
    FROM transferencia t
    WHERE t.cuenta_origen IN (
        SELECT cb.numero_cuenta FROM cuenta_bancaria cb
        JOIN cliente_empresa ce ON cb.id_titular = ce.nit
        WHERE ce.id_usuario = @id_empresa_sesion
    );

-- RP-20: Supervisor Empresa  transferencias pendientes de aprobación
CREATE OR REPLACE VIEW v_transferencias_supervisor AS
    SELECT t.id_transferencia, t.cuenta_origen, t.cuenta_destino,
           t.monto, t.id_estado_transferencia,
           t.fecha_creacion, t.fecha_vencimiento
    FROM transferencia t
    WHERE t.requiere_aprobacion = TRUE
      AND t.id_estado_transferencia = (
          SELECT id_estado_transferencia FROM cat_estado_transferencia
          WHERE nombre_estado = 'En Espera de Aprobacion'
      )
      AND t.cuenta_origen IN (
          SELECT cb.numero_cuenta FROM cuenta_bancaria cb
          JOIN cliente_empresa ce ON cb.id_titular = ce.nit
          WHERE ce.id_usuario = @id_empresa_sesion
      );

-- RP-21: Analista Interno — todos los préstamos
CREATE OR REPLACE VIEW v_prestamos_analista AS
    SELECT * FROM prestamo;

-- RP-21: Analista Interno — bitácora completa (solo lectura)
-- NOTA: ORDER BY se omite en la vista (MySQL 8 lo ignora sin LIMIT).
-- Usar ORDER BY en la consulta que consuma esta vista.
CREATE OR REPLACE VIEW v_bitacora_analista AS
    SELECT id_bitacora, tipo_operacion, fecha_hora_operacion,
           id_usuario, rol_usuario, id_producto_afectado,
           tipo_producto, datos_detalle
    FROM bitacora_cola;
